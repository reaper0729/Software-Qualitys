int abs(int p);
